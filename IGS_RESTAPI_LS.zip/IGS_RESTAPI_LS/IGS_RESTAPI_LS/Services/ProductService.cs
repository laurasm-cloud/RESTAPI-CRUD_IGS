﻿using IGS_RESTAPI_LS.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;


namespace IGS_RESTAPI_LS.Services
{
    public class ProductService
    {
        private readonly IMongoCollection<Products> _productcollection;

        public ProductService(IProductstoreDatabaseSettings settings)
        {
            var client = new MongoClient(settings.ConnectionString);
            var database = client.GetDatabase(settings.DatabaseName);

            _productcollection = database.GetCollection<Products>(settings.ProductCollectionName);
        }

        public List<Products> GetProducts() => _productcollection.Find(Products => true).ToList();


        public Products GetID(int id) =>        
           _productcollection.Find<Products>(Products => Products.ProductId == id).FirstOrDefault();
       

        public Products Create(Products products)
        {
            _productcollection.InsertOne(products);
            return products;
        }

        public void Update(int id, Products productIn) =>
            _productcollection.ReplaceOne(products => products.ProductId == id, productIn);

        public void Remove(Products productIn) =>
            _productcollection.DeleteOne(products => products.ProductId == productIn.ProductId);
        public void Remove(int id) =>
            _productcollection.DeleteOne(products => products.ProductId == id);

       
    }
}
