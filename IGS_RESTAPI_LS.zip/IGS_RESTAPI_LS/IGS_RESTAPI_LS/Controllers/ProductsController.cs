﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using IGS_RESTAPI_LS.Models;
using Microsoft.Extensions.Logging;
using IGS_RESTAPI_LS.Services;

namespace IGS_RESTAPI_LS.Controllers
{
    [Route("api/products")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        
        private readonly ProductService _productService;

        public ProductsController(ProductService productService)
        {
            _productService = productService;
        }

        // GET: api/Products
        [HttpGet]
        public ActionResult<IEnumerable<Products>> GetProducts() =>
                  _productService.GetProducts();
       

        // GET: api/Products/5
        [HttpGet(("{id}"),Name = "GetProduct" )]
        public ActionResult<Products> GetProducts(int id)
        {
            var products = _productService.GetID(id);

            if (products == null)
            {
                return NotFound();
            }

            return products;
        }

        // PUT: api/Products/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [HttpPut("{id}")]
        public IActionResult Update(int id, Products productIn)
        {
            var products = _productService.GetID(id);

            if (products == null)
            {
                return NotFound();
            }

            _productService.Update(id, productIn);

            return NoContent();
        }

        // POST: api/Products
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for
        // more details see https://aka.ms/RazorPagesCRUD.
        [ProducesResponseType(201)]
        [ProducesResponseType(400)]
        [HttpPost]
        public ActionResult<Products> Create(Products products)
        { 
                _productService.Create(products);        

            return CreatedAtRoute(nameof(GetProducts), new { id = products.ProductId.ToString() }, products);
        }

        // DELETE: api/Products/5
        [HttpDelete("{id}")]
        public ActionResult<Products> Delete(int id)
        {
            var products = _productService.GetID(id);
            if (products == null)
            {
                return NotFound();
            }

            _productService.Remove(products);

            return products;
        }

    }
}
