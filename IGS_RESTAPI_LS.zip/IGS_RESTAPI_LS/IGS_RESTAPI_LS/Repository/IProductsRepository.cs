﻿using IGS_RESTAPI_LS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IGS_RESTAPI_LS.Repository
{
  public  interface IProductsRepository
    {
        Task<IEnumerable<Products>> GetAllProducts();
        Task<Products> GetProducts(string name);
        Task Create(Products products);
        Task<bool> Update(Products products);
        Task<bool> Delete(string name);
    }
}
