﻿using IGS_RESTAPI_LS.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MongoDB.Driver;

namespace IGS_RESTAPI_LS.Repository
{
    public class ProductsRepository : IProductsRepository
    {
        private readonly IProductsContext _context;

        public ProductsRepository(IProductsContext context)
        {
            _context = context;
        }
        public async Task Create(Products products)
        {
            await _context.Product.InsertOneAsync(products);
        }

        public Task<bool> Delete(string name)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<Products>> GetAllProducts()
        {
            return await _context
                            .Product
                            .Find(_ => true)
                            .ToListAsync();
        }

        public Task<Products> GetProducts(string name)
        {
            FilterDefinition<Products> filter = Builders<Products>.Filter.Eq(m => m.Name, name);
            return _context
                    .Product
                    .Find(filter)
                    .FirstOrDefaultAsync();
        }

        public async Task<bool> Update(Products products)
        {
            ReplaceOneResult updateResult = await _context.Product.ReplaceOneAsync(
                            filter: p => p.ProductId == products.ProductId,
                            replacement: products);

            return updateResult.IsAcknowledged
                    && updateResult.ModifiedCount > 0;
        }
    }
}
