﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace IGS_RESTAPI_LS.Models
{
    public partial class Products
    {
        [BsonId]
        [BsonRepresentation(MongoDB.Bson.BsonType.ObjectId)]
        public int ProductId { get; set; }

        [BsonElement("Name")]
        public string Name { get; set; }
        public string Price { get; set; }

      //  public virtual ICollection<Products> Prod { get; set; }

    }
}
