﻿using MongoDB.Driver;

namespace IGS_RESTAPI_LS.Models
{
    public interface IProductsContext
    {       
            IMongoCollection<Products> Product { get; }
        
    }
}
