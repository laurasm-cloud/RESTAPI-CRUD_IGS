﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;

namespace IGS_RESTAPI_LS.Models
{
    public partial class ProductsContext : IProductsContext
    {
        private readonly IMongoDatabase _productdb;

        public ProductsContext(IOptions<MongoClientSettings> option, IMongoClient client)
        {
            //  _productdb = client.GetDatabase(option.Value.Database);
            _productdb = client.GetDatabase(option.Value.Database);
        }

        IMongoCollection<Products> Product => _productdb.GetCollection<Products>("Product");

        IMongoCollection<Products> IProductsContext.Product => throw new System.NotImplementedException();
    }
}
